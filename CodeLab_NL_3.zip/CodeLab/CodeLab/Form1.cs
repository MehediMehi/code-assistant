﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CodeLab
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void learnLanguage_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            selectLanguageL sl = new selectLanguageL();
            sl.Show();
        }

        private void codes_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            codes c = new codes();
            c.Show();
        }

        private void compiler_button_Click(object sender, EventArgs e)
        {

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.ExitThread();
        }
    }
}
