﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CodeLab
{
    public partial class selectLanguageL : Form
    {
        public selectLanguageL()
        {
            InitializeComponent();
        }

        private void learnC_button_Click(object sender, EventArgs e)
        {

        }

        private void learnCpp_button_Click(object sender, EventArgs e)
        {

        }

        private void learnCsrp_button_Click(object sender, EventArgs e)
        {

        }

        private void back_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home h = new Home();
            h.Show();
        }

        private void home_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home h = new Home();
            h.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.ExitThread();
        }

        private void head_menu_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
    }
}
