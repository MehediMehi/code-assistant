﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CodeLab
{
    public partial class bHelloWorld : Form
    {
        public bHelloWorld()
        {
            InitializeComponent();
        }

        private void back_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            beginnerCodes bc = new beginnerCodes();
            bc.Show();
        }

        private void home_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home h = new Home();
            h.Show();
        }

        private void run_button_Click(object sender, EventArgs e)
        {
            output.Text = "Hello World!";
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.ExitThread();
        }

        private void viewCode_button_Click(object sender, EventArgs e)
        {
            bHWview b = new bHWview();
            b.ShowDialog();
        }
    }
}
