﻿namespace CodeLab
{
    partial class beginnerCodes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.bEvenOdd_button = new System.Windows.Forms.Button();
            this.bSwap_button = new System.Windows.Forms.Button();
            this.bLargeNum_button = new System.Windows.Forms.Button();
            this.bAdd2num_button = new System.Windows.Forms.Button();
            this.bHelloWorld_button = new System.Windows.Forms.Button();
            this.home_button = new System.Windows.Forms.Button();
            this.back_button = new System.Windows.Forms.Button();
            this.head_menu = new System.Windows.Forms.MenuStrip();
            this.menuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.applicationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.developersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.bAscii_button = new System.Windows.Forms.Button();
            this.bAreaCircle_button = new System.Windows.Forms.Button();
            this.head_menu.SuspendLayout();
            this.SuspendLayout();
            // 
            // bEvenOdd_button
            // 
            this.bEvenOdd_button.AllowDrop = true;
            this.bEvenOdd_button.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bEvenOdd_button.BackColor = System.Drawing.Color.LightSkyBlue;
            this.bEvenOdd_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bEvenOdd_button.FlatAppearance.BorderSize = 0;
            this.bEvenOdd_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DodgerBlue;
            this.bEvenOdd_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bEvenOdd_button.Location = new System.Drawing.Point(150, 236);
            this.bEvenOdd_button.Name = "bEvenOdd_button";
            this.bEvenOdd_button.Size = new System.Drawing.Size(177, 25);
            this.bEvenOdd_button.TabIndex = 66;
            this.bEvenOdd_button.Text = "Even Odd";
            this.toolTip.SetToolTip(this.bEvenOdd_button, "Even or Odd number");
            this.bEvenOdd_button.UseVisualStyleBackColor = false;
            this.bEvenOdd_button.Click += new System.EventHandler(this.bEvenOdd_button_Click);
            // 
            // bSwap_button
            // 
            this.bSwap_button.AllowDrop = true;
            this.bSwap_button.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bSwap_button.BackColor = System.Drawing.Color.LightSkyBlue;
            this.bSwap_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bSwap_button.FlatAppearance.BorderSize = 0;
            this.bSwap_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DodgerBlue;
            this.bSwap_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bSwap_button.Location = new System.Drawing.Point(150, 205);
            this.bSwap_button.Name = "bSwap_button";
            this.bSwap_button.Size = new System.Drawing.Size(177, 25);
            this.bSwap_button.TabIndex = 65;
            this.bSwap_button.Text = "Swap numbers";
            this.toolTip.SetToolTip(this.bSwap_button, "Swap two numbers");
            this.bSwap_button.UseVisualStyleBackColor = false;
            this.bSwap_button.Click += new System.EventHandler(this.bSwap_button_Click);
            // 
            // bLargeNum_button
            // 
            this.bLargeNum_button.AllowDrop = true;
            this.bLargeNum_button.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bLargeNum_button.BackColor = System.Drawing.Color.LightSkyBlue;
            this.bLargeNum_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bLargeNum_button.FlatAppearance.BorderSize = 0;
            this.bLargeNum_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DodgerBlue;
            this.bLargeNum_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bLargeNum_button.Location = new System.Drawing.Point(150, 174);
            this.bLargeNum_button.Name = "bLargeNum_button";
            this.bLargeNum_button.Size = new System.Drawing.Size(177, 25);
            this.bLargeNum_button.TabIndex = 64;
            this.bLargeNum_button.Text = "Largest of 3 numbers";
            this.toolTip.SetToolTip(this.bLargeNum_button, "Largest of three numbers");
            this.bLargeNum_button.UseVisualStyleBackColor = false;
            this.bLargeNum_button.Click += new System.EventHandler(this.bLargeNum_button_Click);
            // 
            // bAdd2num_button
            // 
            this.bAdd2num_button.AllowDrop = true;
            this.bAdd2num_button.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bAdd2num_button.BackColor = System.Drawing.Color.LightSkyBlue;
            this.bAdd2num_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bAdd2num_button.FlatAppearance.BorderSize = 0;
            this.bAdd2num_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DodgerBlue;
            this.bAdd2num_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bAdd2num_button.Location = new System.Drawing.Point(150, 143);
            this.bAdd2num_button.Name = "bAdd2num_button";
            this.bAdd2num_button.Size = new System.Drawing.Size(177, 25);
            this.bAdd2num_button.TabIndex = 63;
            this.bAdd2num_button.Text = "Add two numbers";
            this.toolTip.SetToolTip(this.bAdd2num_button, "Addition of two numbers");
            this.bAdd2num_button.UseVisualStyleBackColor = false;
            this.bAdd2num_button.Click += new System.EventHandler(this.bAdd2num_button_Click);
            // 
            // bHelloWorld_button
            // 
            this.bHelloWorld_button.AllowDrop = true;
            this.bHelloWorld_button.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bHelloWorld_button.BackColor = System.Drawing.Color.LightSkyBlue;
            this.bHelloWorld_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bHelloWorld_button.FlatAppearance.BorderSize = 0;
            this.bHelloWorld_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DodgerBlue;
            this.bHelloWorld_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bHelloWorld_button.Location = new System.Drawing.Point(150, 112);
            this.bHelloWorld_button.Name = "bHelloWorld_button";
            this.bHelloWorld_button.Size = new System.Drawing.Size(177, 25);
            this.bHelloWorld_button.TabIndex = 62;
            this.bHelloWorld_button.Text = "Hello World!";
            this.toolTip.SetToolTip(this.bHelloWorld_button, "Hello World");
            this.bHelloWorld_button.UseVisualStyleBackColor = false;
            this.bHelloWorld_button.Click += new System.EventHandler(this.bHelloWorld_button_Click);
            // 
            // home_button
            // 
            this.home_button.BackColor = System.Drawing.Color.Transparent;
            this.home_button.FlatAppearance.BorderSize = 0;
            this.home_button.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGreen;
            this.home_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumSpringGreen;
            this.home_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.home_button.Image = global::CodeLab.Properties.Resources.homeicon;
            this.home_button.Location = new System.Drawing.Point(48, 27);
            this.home_button.Name = "home_button";
            this.home_button.Size = new System.Drawing.Size(40, 40);
            this.home_button.TabIndex = 69;
            this.toolTip.SetToolTip(this.home_button, "Home");
            this.home_button.UseVisualStyleBackColor = false;
            this.home_button.Click += new System.EventHandler(this.home_button_Click);
            // 
            // back_button
            // 
            this.back_button.BackColor = System.Drawing.Color.Transparent;
            this.back_button.FlatAppearance.BorderSize = 0;
            this.back_button.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DodgerBlue;
            this.back_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.back_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.back_button.Image = global::CodeLab.Properties.Resources.backiconbs;
            this.back_button.Location = new System.Drawing.Point(0, 27);
            this.back_button.Name = "back_button";
            this.back_button.Size = new System.Drawing.Size(42, 40);
            this.back_button.TabIndex = 68;
            this.toolTip.SetToolTip(this.back_button, "Back");
            this.back_button.UseVisualStyleBackColor = false;
            this.back_button.Click += new System.EventHandler(this.back_button_Click);
            // 
            // head_menu
            // 
            this.head_menu.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.head_menu.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.head_menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuToolStripMenuItem,
            this.aboutToolStripMenuItem});
            this.head_menu.Location = new System.Drawing.Point(0, 0);
            this.head_menu.Name = "head_menu";
            this.head_menu.Size = new System.Drawing.Size(468, 24);
            this.head_menu.TabIndex = 67;
            this.head_menu.Text = "Menu";
            // 
            // menuToolStripMenuItem
            // 
            this.menuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.menuToolStripMenuItem.Name = "menuToolStripMenuItem";
            this.menuToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.menuToolStripMenuItem.Text = "Menu";
            this.menuToolStripMenuItem.ToolTipText = "Menu";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(92, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.ToolTipText = "Exit application";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.applicationToolStripMenuItem,
            this.developersToolStripMenuItem});
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.ToolTipText = "About";
            // 
            // applicationToolStripMenuItem
            // 
            this.applicationToolStripMenuItem.Name = "applicationToolStripMenuItem";
            this.applicationToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
            this.applicationToolStripMenuItem.Text = "Application";
            this.applicationToolStripMenuItem.ToolTipText = "About application";
            // 
            // developersToolStripMenuItem
            // 
            this.developersToolStripMenuItem.Name = "developersToolStripMenuItem";
            this.developersToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
            this.developersToolStripMenuItem.Text = "Developers";
            this.developersToolStripMenuItem.ToolTipText = "About developers";
            // 
            // toolTip
            // 
            this.toolTip.BackColor = System.Drawing.Color.LightSteelBlue;
            // 
            // bAscii_button
            // 
            this.bAscii_button.AllowDrop = true;
            this.bAscii_button.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bAscii_button.BackColor = System.Drawing.Color.LightSkyBlue;
            this.bAscii_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bAscii_button.FlatAppearance.BorderSize = 0;
            this.bAscii_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DodgerBlue;
            this.bAscii_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bAscii_button.Location = new System.Drawing.Point(150, 267);
            this.bAscii_button.Name = "bAscii_button";
            this.bAscii_button.Size = new System.Drawing.Size(177, 25);
            this.bAscii_button.TabIndex = 70;
            this.bAscii_button.Text = "ASCII value";
            this.toolTip.SetToolTip(this.bAscii_button, "Find ASCII value");
            this.bAscii_button.UseVisualStyleBackColor = false;
            this.bAscii_button.Click += new System.EventHandler(this.bAscii_button_Click);
            // 
            // bAreaCircle_button
            // 
            this.bAreaCircle_button.AllowDrop = true;
            this.bAreaCircle_button.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bAreaCircle_button.BackColor = System.Drawing.Color.LightSkyBlue;
            this.bAreaCircle_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bAreaCircle_button.FlatAppearance.BorderSize = 0;
            this.bAreaCircle_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DodgerBlue;
            this.bAreaCircle_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bAreaCircle_button.Location = new System.Drawing.Point(150, 298);
            this.bAreaCircle_button.Name = "bAreaCircle_button";
            this.bAreaCircle_button.Size = new System.Drawing.Size(177, 25);
            this.bAreaCircle_button.TabIndex = 71;
            this.bAreaCircle_button.Text = "Area of circle";
            this.toolTip.SetToolTip(this.bAreaCircle_button, "Area of circle");
            this.bAreaCircle_button.UseVisualStyleBackColor = false;
            this.bAreaCircle_button.Click += new System.EventHandler(this.bAreaCircle_button_Click);
            // 
            // beginnerCodes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CodeLab.Properties.Resources.codebg;
            this.ClientSize = new System.Drawing.Size(468, 401);
            this.Controls.Add(this.bAreaCircle_button);
            this.Controls.Add(this.bAscii_button);
            this.Controls.Add(this.home_button);
            this.Controls.Add(this.back_button);
            this.Controls.Add(this.head_menu);
            this.Controls.Add(this.bEvenOdd_button);
            this.Controls.Add(this.bSwap_button);
            this.Controls.Add(this.bLargeNum_button);
            this.Controls.Add(this.bAdd2num_button);
            this.Controls.Add(this.bHelloWorld_button);
            this.Name = "beginnerCodes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Beginner level";
            this.head_menu.ResumeLayout(false);
            this.head_menu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bEvenOdd_button;
        private System.Windows.Forms.Button bSwap_button;
        private System.Windows.Forms.Button bLargeNum_button;
        private System.Windows.Forms.Button bAdd2num_button;
        private System.Windows.Forms.Button bHelloWorld_button;
        private System.Windows.Forms.Button home_button;
        private System.Windows.Forms.Button back_button;
        private System.Windows.Forms.MenuStrip head_menu;
        private System.Windows.Forms.ToolStripMenuItem menuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem applicationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem developersToolStripMenuItem;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.Button bAscii_button;
        private System.Windows.Forms.Button bAreaCircle_button;
    }
}