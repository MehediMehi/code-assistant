﻿namespace CodeLab
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.head_menu = new System.Windows.Forms.MenuStrip();
            this.menuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.applicationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.developersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.compiler_button = new System.Windows.Forms.Button();
            this.learnLanguage_button = new System.Windows.Forms.Button();
            this.codes_button = new System.Windows.Forms.Button();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.head_menu.SuspendLayout();
            this.SuspendLayout();
            // 
            // head_menu
            // 
            this.head_menu.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.head_menu.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.head_menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuToolStripMenuItem,
            this.aboutToolStripMenuItem});
            this.head_menu.Location = new System.Drawing.Point(0, 0);
            this.head_menu.Name = "head_menu";
            this.head_menu.Size = new System.Drawing.Size(524, 24);
            this.head_menu.TabIndex = 7;
            this.head_menu.Text = "Menu";
            // 
            // menuToolStripMenuItem
            // 
            this.menuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.menuToolStripMenuItem.Name = "menuToolStripMenuItem";
            this.menuToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.menuToolStripMenuItem.Text = "Menu";
            this.menuToolStripMenuItem.ToolTipText = "Menu";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(92, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.ToolTipText = "Exit application";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.applicationToolStripMenuItem,
            this.developersToolStripMenuItem});
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.ToolTipText = "About";
            // 
            // applicationToolStripMenuItem
            // 
            this.applicationToolStripMenuItem.Name = "applicationToolStripMenuItem";
            this.applicationToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
            this.applicationToolStripMenuItem.Text = "Application";
            this.applicationToolStripMenuItem.ToolTipText = "About application";
            // 
            // developersToolStripMenuItem
            // 
            this.developersToolStripMenuItem.Name = "developersToolStripMenuItem";
            this.developersToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
            this.developersToolStripMenuItem.Text = "Developers";
            this.developersToolStripMenuItem.ToolTipText = "About developers";
            // 
            // compiler_button
            // 
            this.compiler_button.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.compiler_button.BackColor = System.Drawing.Color.Transparent;
            this.compiler_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.compiler_button.FlatAppearance.BorderSize = 0;
            this.compiler_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.compiler_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.compiler_button.ForeColor = System.Drawing.Color.DodgerBlue;
            this.compiler_button.Location = new System.Drawing.Point(196, 249);
            this.compiler_button.Name = "compiler_button";
            this.compiler_button.Size = new System.Drawing.Size(137, 67);
            this.compiler_button.TabIndex = 6;
            this.compiler_button.Text = "Compiler";
            this.toolTip.SetToolTip(this.compiler_button, "Compiler");
            this.compiler_button.UseVisualStyleBackColor = false;
            this.compiler_button.Click += new System.EventHandler(this.compiler_button_Click);
            // 
            // learnLanguage_button
            // 
            this.learnLanguage_button.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.learnLanguage_button.BackColor = System.Drawing.Color.Transparent;
            this.learnLanguage_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.learnLanguage_button.FlatAppearance.BorderSize = 0;
            this.learnLanguage_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.learnLanguage_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.learnLanguage_button.ForeColor = System.Drawing.Color.DodgerBlue;
            this.learnLanguage_button.Location = new System.Drawing.Point(196, 80);
            this.learnLanguage_button.Name = "learnLanguage_button";
            this.learnLanguage_button.Size = new System.Drawing.Size(137, 66);
            this.learnLanguage_button.TabIndex = 5;
            this.learnLanguage_button.Text = "Learn Languages";
            this.toolTip.SetToolTip(this.learnLanguage_button, "Learn programming languages");
            this.learnLanguage_button.UseVisualStyleBackColor = false;
            this.learnLanguage_button.Click += new System.EventHandler(this.learnLanguage_button_Click);
            // 
            // codes_button
            // 
            this.codes_button.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.codes_button.BackColor = System.Drawing.Color.Transparent;
            this.codes_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.codes_button.FlatAppearance.BorderSize = 0;
            this.codes_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.codes_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.codes_button.ForeColor = System.Drawing.Color.DodgerBlue;
            this.codes_button.Location = new System.Drawing.Point(196, 167);
            this.codes_button.Name = "codes_button";
            this.codes_button.Size = new System.Drawing.Size(137, 62);
            this.codes_button.TabIndex = 4;
            this.codes_button.Text = "Codes";
            this.toolTip.SetToolTip(this.codes_button, "Practice codes");
            this.codes_button.UseVisualStyleBackColor = false;
            this.codes_button.Click += new System.EventHandler(this.codes_button_Click);
            // 
            // toolTip
            // 
            this.toolTip.BackColor = System.Drawing.Color.LightSteelBlue;
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CodeLab.Properties.Resources.Csrpbackground;
            this.ClientSize = new System.Drawing.Size(524, 414);
            this.Controls.Add(this.head_menu);
            this.Controls.Add(this.compiler_button);
            this.Controls.Add(this.learnLanguage_button);
            this.Controls.Add(this.codes_button);
            this.Name = "Home";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Home";
            this.head_menu.ResumeLayout(false);
            this.head_menu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip head_menu;
        private System.Windows.Forms.ToolStripMenuItem menuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.Button compiler_button;
        private System.Windows.Forms.Button learnLanguage_button;
        private System.Windows.Forms.Button codes_button;
        private System.Windows.Forms.ToolStripMenuItem applicationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem developersToolStripMenuItem;
        private System.Windows.Forms.ToolTip toolTip;
    }
}

