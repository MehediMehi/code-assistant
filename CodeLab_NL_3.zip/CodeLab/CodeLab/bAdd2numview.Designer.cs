﻿namespace CodeLab
{
    partial class bAdd2numview
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.viewCSRPcode_button = new System.Windows.Forms.Button();
            this.viewCPPcode_button = new System.Windows.Forms.Button();
            this.viewCcode_button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.label1.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label1.Location = new System.Drawing.Point(138, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(146, 24);
            this.label1.TabIndex = 120;
            this.label1.Text = "Select language";
            // 
            // viewCSRPcode_button
            // 
            this.viewCSRPcode_button.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.viewCSRPcode_button.BackColor = System.Drawing.Color.Transparent;
            this.viewCSRPcode_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.viewCSRPcode_button.FlatAppearance.BorderSize = 0;
            this.viewCSRPcode_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.viewCSRPcode_button.Image = global::CodeLab.Properties.Resources.csharp;
            this.viewCSRPcode_button.Location = new System.Drawing.Point(300, 68);
            this.viewCSRPcode_button.Name = "viewCSRPcode_button";
            this.viewCSRPcode_button.Size = new System.Drawing.Size(108, 108);
            this.viewCSRPcode_button.TabIndex = 119;
            this.viewCSRPcode_button.UseVisualStyleBackColor = false;
            this.viewCSRPcode_button.Click += new System.EventHandler(this.viewCSRPcode_button_Click);
            // 
            // viewCPPcode_button
            // 
            this.viewCPPcode_button.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.viewCPPcode_button.BackColor = System.Drawing.Color.Transparent;
            this.viewCPPcode_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.viewCPPcode_button.FlatAppearance.BorderSize = 0;
            this.viewCPPcode_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.viewCPPcode_button.Image = global::CodeLab.Properties.Resources.cpp;
            this.viewCPPcode_button.Location = new System.Drawing.Point(157, 68);
            this.viewCPPcode_button.Name = "viewCPPcode_button";
            this.viewCPPcode_button.Size = new System.Drawing.Size(108, 108);
            this.viewCPPcode_button.TabIndex = 118;
            this.viewCPPcode_button.UseVisualStyleBackColor = false;
            this.viewCPPcode_button.Click += new System.EventHandler(this.viewCPPcode_button_Click);
            // 
            // viewCcode_button
            // 
            this.viewCcode_button.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.viewCcode_button.BackColor = System.Drawing.Color.Transparent;
            this.viewCcode_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.viewCcode_button.FlatAppearance.BorderSize = 0;
            this.viewCcode_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.viewCcode_button.ForeColor = System.Drawing.Color.Transparent;
            this.viewCcode_button.Image = global::CodeLab.Properties.Resources.c;
            this.viewCcode_button.Location = new System.Drawing.Point(14, 68);
            this.viewCcode_button.Name = "viewCcode_button";
            this.viewCcode_button.Size = new System.Drawing.Size(108, 108);
            this.viewCcode_button.TabIndex = 117;
            this.viewCcode_button.UseVisualStyleBackColor = false;
            this.viewCcode_button.Click += new System.EventHandler(this.viewCcode_button_Click);
            // 
            // bAdd2numview
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CodeLab.Properties.Resources.viewC;
            this.ClientSize = new System.Drawing.Size(421, 189);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.viewCSRPcode_button);
            this.Controls.Add(this.viewCPPcode_button);
            this.Controls.Add(this.viewCcode_button);
            this.Name = "bAdd2numview";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "View code";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button viewCSRPcode_button;
        private System.Windows.Forms.Button viewCPPcode_button;
        private System.Windows.Forms.Button viewCcode_button;
    }
}