﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CodeLab
{
    public partial class beginnerCodes : Form
    {
        public beginnerCodes()
        {
            InitializeComponent();
        }

        private void back_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            codes c = new codes();
            c.Show();
        }

        private void home_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home h = new Home();
            h.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.ExitThread();
        }

        private void bHelloWorld_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            bHelloWorld hw = new bHelloWorld();
            hw.Show();
        }

        private void bAdd2num_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            bAdd2Num a = new bAdd2Num();
            a.Show();
        }

        private void bLargeNum_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            bLrgOfThreeNum l = new bLrgOfThreeNum();
            l.Show();
        }

        private void bSwap_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            bSwap s = new bSwap();
            s.Show();
        }

        private void bEvenOdd_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            bEvenOdd eo = new bEvenOdd();
            eo.Show();
        }

        private void bAscii_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            bASCII a = new bASCII();
            a.Show();
        }

        private void bAreaCircle_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            bAreaOfCircle a = new bAreaOfCircle();
            a.Show();
        }
    }
}
