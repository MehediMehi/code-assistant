﻿namespace CodeLab
{
    partial class selectLanguageL
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.home_button = new System.Windows.Forms.Button();
            this.back_button = new System.Windows.Forms.Button();
            this.head_menu = new System.Windows.Forms.MenuStrip();
            this.menuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.applicationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.developersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.learnCsrp_button = new System.Windows.Forms.Button();
            this.learnCpp_button = new System.Windows.Forms.Button();
            this.learnC_button = new System.Windows.Forms.Button();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.head_menu.SuspendLayout();
            this.SuspendLayout();
            // 
            // home_button
            // 
            this.home_button.BackColor = System.Drawing.Color.Transparent;
            this.home_button.FlatAppearance.BorderSize = 0;
            this.home_button.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGreen;
            this.home_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumSpringGreen;
            this.home_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.home_button.Image = global::CodeLab.Properties.Resources.homeicon;
            this.home_button.Location = new System.Drawing.Point(48, 27);
            this.home_button.Name = "home_button";
            this.home_button.Size = new System.Drawing.Size(40, 40);
            this.home_button.TabIndex = 30;
            this.toolTip.SetToolTip(this.home_button, "Home");
            this.home_button.UseVisualStyleBackColor = false;
            this.home_button.Click += new System.EventHandler(this.home_button_Click);
            // 
            // back_button
            // 
            this.back_button.BackColor = System.Drawing.Color.Transparent;
            this.back_button.FlatAppearance.BorderSize = 0;
            this.back_button.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DodgerBlue;
            this.back_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.back_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.back_button.Image = global::CodeLab.Properties.Resources.backiconbs;
            this.back_button.Location = new System.Drawing.Point(0, 27);
            this.back_button.Name = "back_button";
            this.back_button.Size = new System.Drawing.Size(42, 40);
            this.back_button.TabIndex = 29;
            this.toolTip.SetToolTip(this.back_button, "Back");
            this.back_button.UseVisualStyleBackColor = false;
            this.back_button.Click += new System.EventHandler(this.back_button_Click);
            // 
            // head_menu
            // 
            this.head_menu.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.head_menu.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.head_menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuToolStripMenuItem,
            this.aboutToolStripMenuItem});
            this.head_menu.Location = new System.Drawing.Point(0, 0);
            this.head_menu.Name = "head_menu";
            this.head_menu.Size = new System.Drawing.Size(423, 24);
            this.head_menu.TabIndex = 28;
            this.head_menu.Text = "Menu";
            this.head_menu.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.head_menu_ItemClicked);
            // 
            // menuToolStripMenuItem
            // 
            this.menuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.menuToolStripMenuItem.Name = "menuToolStripMenuItem";
            this.menuToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.menuToolStripMenuItem.Text = "Menu";
            this.menuToolStripMenuItem.ToolTipText = "Menu";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(92, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.ToolTipText = "Exit application";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.applicationToolStripMenuItem,
            this.developersToolStripMenuItem});
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.ToolTipText = "About";
            // 
            // applicationToolStripMenuItem
            // 
            this.applicationToolStripMenuItem.Name = "applicationToolStripMenuItem";
            this.applicationToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
            this.applicationToolStripMenuItem.Text = "Application";
            this.applicationToolStripMenuItem.ToolTipText = "About application";
            // 
            // developersToolStripMenuItem
            // 
            this.developersToolStripMenuItem.Name = "developersToolStripMenuItem";
            this.developersToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
            this.developersToolStripMenuItem.Text = "Developers";
            this.developersToolStripMenuItem.ToolTipText = "About developers";
            // 
            // learnCsrp_button
            // 
            this.learnCsrp_button.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.learnCsrp_button.BackColor = System.Drawing.Color.Transparent;
            this.learnCsrp_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.learnCsrp_button.FlatAppearance.BorderSize = 0;
            this.learnCsrp_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.learnCsrp_button.Image = global::CodeLab.Properties.Resources.csharp;
            this.learnCsrp_button.Location = new System.Drawing.Point(300, 146);
            this.learnCsrp_button.Name = "learnCsrp_button";
            this.learnCsrp_button.Size = new System.Drawing.Size(108, 108);
            this.learnCsrp_button.TabIndex = 33;
            this.toolTip.SetToolTip(this.learnCsrp_button, "Learn C# language");
            this.learnCsrp_button.UseVisualStyleBackColor = false;
            this.learnCsrp_button.Click += new System.EventHandler(this.learnCsrp_button_Click);
            // 
            // learnCpp_button
            // 
            this.learnCpp_button.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.learnCpp_button.BackColor = System.Drawing.Color.Transparent;
            this.learnCpp_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.learnCpp_button.FlatAppearance.BorderSize = 0;
            this.learnCpp_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.learnCpp_button.Image = global::CodeLab.Properties.Resources.cpp;
            this.learnCpp_button.Location = new System.Drawing.Point(157, 146);
            this.learnCpp_button.Name = "learnCpp_button";
            this.learnCpp_button.Size = new System.Drawing.Size(108, 108);
            this.learnCpp_button.TabIndex = 32;
            this.toolTip.SetToolTip(this.learnCpp_button, "Learn C++ language");
            this.learnCpp_button.UseVisualStyleBackColor = false;
            this.learnCpp_button.Click += new System.EventHandler(this.learnCpp_button_Click);
            // 
            // learnC_button
            // 
            this.learnC_button.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.learnC_button.BackColor = System.Drawing.Color.Transparent;
            this.learnC_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.learnC_button.FlatAppearance.BorderSize = 0;
            this.learnC_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.learnC_button.ForeColor = System.Drawing.Color.Transparent;
            this.learnC_button.Image = global::CodeLab.Properties.Resources.c;
            this.learnC_button.Location = new System.Drawing.Point(14, 146);
            this.learnC_button.Name = "learnC_button";
            this.learnC_button.Size = new System.Drawing.Size(108, 108);
            this.learnC_button.TabIndex = 31;
            this.toolTip.SetToolTip(this.learnC_button, "Learn C language");
            this.learnC_button.UseVisualStyleBackColor = false;
            this.learnC_button.Click += new System.EventHandler(this.learnC_button_Click);
            // 
            // toolTip
            // 
            this.toolTip.BackColor = System.Drawing.Color.LightSteelBlue;
            // 
            // selectLanguageL
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CodeLab.Properties.Resources.Cbackground;
            this.ClientSize = new System.Drawing.Size(423, 401);
            this.Controls.Add(this.learnCsrp_button);
            this.Controls.Add(this.learnCpp_button);
            this.Controls.Add(this.learnC_button);
            this.Controls.Add(this.home_button);
            this.Controls.Add(this.back_button);
            this.Controls.Add(this.head_menu);
            this.Name = "selectLanguageL";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Select language";
            this.head_menu.ResumeLayout(false);
            this.head_menu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button home_button;
        private System.Windows.Forms.Button back_button;
        private System.Windows.Forms.MenuStrip head_menu;
        private System.Windows.Forms.ToolStripMenuItem menuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem applicationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem developersToolStripMenuItem;
        private System.Windows.Forms.Button learnCsrp_button;
        private System.Windows.Forms.Button learnCpp_button;
        private System.Windows.Forms.Button learnC_button;
        private System.Windows.Forms.ToolTip toolTip;
    }
}