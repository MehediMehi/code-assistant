﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CodeLab
{
    public partial class bASCII : Form
    {
        public bASCII()
        {
            InitializeComponent();
        }

        private void run_button_Click(object sender, EventArgs e)
        {
            char value1 = char.Parse(textBox1.Text);
            int value2 = (int)value1;
            output.Text = "The ASCII value of " + System.Convert.ToString(value1) + " is " + System.Convert.ToInt32(value2);
        }

        private void back_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            beginnerCodes bc = new beginnerCodes();
            bc.Show();
        }

        private void home_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home h = new Home();
            h.Show();
        }

        private void clear_button_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            output.Text = "";
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.ExitThread();
        }
    }
}
