﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CodeLab
{
    public partial class bLrgOfThreeNum : Form
    {
        public bLrgOfThreeNum()
        {
            InitializeComponent();
        }

        private void back_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            beginnerCodes bc = new beginnerCodes();
            bc.Show();
        }

        private void home_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home h = new Home();
            h.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.ExitThread();
        }

        private void clear_button_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            output.Text = "";
        }

        private void run_button_Click(object sender, EventArgs e)
        {
            double value1 = double.Parse(textBox1.Text);
            double value2 = double.Parse(textBox2.Text);
            double value3 = double.Parse(textBox3.Text);

            if (value1 >= value2 && value1 >= value3)
            {
                output.Text = System.Convert.ToString(value1);
            }
            else if (value2 >= value1 && value2 >= value3)
            {
                output.Text = System.Convert.ToString(value2);
            }
            else if (value3 >= value2 && value3 >= value1)
            {
                output.Text = System.Convert.ToString(value3);
            }
        }
    }
}
