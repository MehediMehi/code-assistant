﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CodeLab
{
    public partial class bEvenOdd : Form
    {
        public bEvenOdd()
        {
            InitializeComponent();
        }

        private void bEvenOdd_Load(object sender, EventArgs e)
        {

        }

        private void back_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            beginnerCodes bc = new beginnerCodes();
            bc.Show();
        }

        private void home_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home h = new Home();
            h.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.ExitThread();
        }

        private void clear_button_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            output.Text = "";
        }

        private void run_button_Click(object sender, EventArgs e)
        {
            int value1 = int.Parse(textBox1.Text);
            if (value1 % 2 == 0)
            {
                output.Text = System.Convert.ToString(value1) + " is even";
            }
            else
            {
                output.Text = System.Convert.ToString(value1) + " is odd";
            }
        }
    }
}
