﻿namespace CodeLab
{
    partial class bASCII
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.clear_button = new System.Windows.Forms.Button();
            this.output = new System.Windows.Forms.Label();
            this.outputTag = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.run_button = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.viewCode_button = new System.Windows.Forms.Button();
            this.home_button = new System.Windows.Forms.Button();
            this.back_button = new System.Windows.Forms.Button();
            this.head_menu = new System.Windows.Forms.MenuStrip();
            this.menuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.applicationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.developersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.head_menu.SuspendLayout();
            this.SuspendLayout();
            // 
            // clear_button
            // 
            this.clear_button.AllowDrop = true;
            this.clear_button.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.clear_button.BackColor = System.Drawing.Color.LightSkyBlue;
            this.clear_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.clear_button.FlatAppearance.BorderSize = 0;
            this.clear_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DodgerBlue;
            this.clear_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.clear_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clear_button.Location = new System.Drawing.Point(360, 190);
            this.clear_button.Name = "clear_button";
            this.clear_button.Size = new System.Drawing.Size(53, 33);
            this.clear_button.TabIndex = 110;
            this.clear_button.Text = "Clear";
            this.toolTip.SetToolTip(this.clear_button, "Clear entries");
            this.clear_button.UseVisualStyleBackColor = false;
            this.clear_button.Click += new System.EventHandler(this.clear_button_Click);
            // 
            // output
            // 
            this.output.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.output.AutoSize = true;
            this.output.BackColor = System.Drawing.Color.Transparent;
            this.output.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.output.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.output.Location = new System.Drawing.Point(97, 250);
            this.output.Name = "output";
            this.output.Size = new System.Drawing.Size(0, 20);
            this.output.TabIndex = 109;
            // 
            // outputTag
            // 
            this.outputTag.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.outputTag.AutoSize = true;
            this.outputTag.BackColor = System.Drawing.Color.Transparent;
            this.outputTag.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.outputTag.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.outputTag.Location = new System.Drawing.Point(21, 250);
            this.outputTag.Name = "outputTag";
            this.outputTag.Size = new System.Drawing.Size(70, 20);
            this.outputTag.TabIndex = 108;
            this.outputTag.Text = "Ouptut : ";
            // 
            // textBox1
            // 
            this.textBox1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBox1.BackColor = System.Drawing.Color.LightSteelBlue;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(261, 121);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(45, 21);
            this.textBox1.TabIndex = 107;
            this.toolTip.SetToolTip(this.textBox1, "Insert character");
            // 
            // run_button
            // 
            this.run_button.AllowDrop = true;
            this.run_button.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.run_button.BackColor = System.Drawing.Color.LightSkyBlue;
            this.run_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.run_button.FlatAppearance.BorderSize = 0;
            this.run_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DodgerBlue;
            this.run_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.run_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.run_button.Location = new System.Drawing.Point(301, 190);
            this.run_button.Name = "run_button";
            this.run_button.Size = new System.Drawing.Size(53, 33);
            this.run_button.TabIndex = 106;
            this.run_button.Text = "Run";
            this.toolTip.SetToolTip(this.run_button, "Run");
            this.run_button.UseVisualStyleBackColor = false;
            this.run_button.Click += new System.EventHandler(this.run_button_Click);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label1.Location = new System.Drawing.Point(97, 122);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(145, 20);
            this.label1.TabIndex = 105;
            this.label1.Text = "Enter a character =";
            // 
            // viewCode_button
            // 
            this.viewCode_button.BackColor = System.Drawing.Color.Transparent;
            this.viewCode_button.FlatAppearance.BorderSize = 0;
            this.viewCode_button.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGreen;
            this.viewCode_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumSpringGreen;
            this.viewCode_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.viewCode_button.Image = global::CodeLab.Properties.Resources.viewg;
            this.viewCode_button.Location = new System.Drawing.Point(94, 27);
            this.viewCode_button.Name = "viewCode_button";
            this.viewCode_button.Size = new System.Drawing.Size(40, 40);
            this.viewCode_button.TabIndex = 104;
            this.toolTip.SetToolTip(this.viewCode_button, "View code");
            this.viewCode_button.UseVisualStyleBackColor = false;
            // 
            // home_button
            // 
            this.home_button.BackColor = System.Drawing.Color.Transparent;
            this.home_button.FlatAppearance.BorderSize = 0;
            this.home_button.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGreen;
            this.home_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumSpringGreen;
            this.home_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.home_button.Image = global::CodeLab.Properties.Resources.homeicon;
            this.home_button.Location = new System.Drawing.Point(48, 27);
            this.home_button.Name = "home_button";
            this.home_button.Size = new System.Drawing.Size(40, 40);
            this.home_button.TabIndex = 103;
            this.toolTip.SetToolTip(this.home_button, "Home");
            this.home_button.UseVisualStyleBackColor = false;
            this.home_button.Click += new System.EventHandler(this.home_button_Click);
            // 
            // back_button
            // 
            this.back_button.BackColor = System.Drawing.Color.Transparent;
            this.back_button.FlatAppearance.BorderSize = 0;
            this.back_button.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DodgerBlue;
            this.back_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.back_button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.back_button.Image = global::CodeLab.Properties.Resources.backiconbs;
            this.back_button.Location = new System.Drawing.Point(0, 27);
            this.back_button.Name = "back_button";
            this.back_button.Size = new System.Drawing.Size(42, 40);
            this.back_button.TabIndex = 102;
            this.toolTip.SetToolTip(this.back_button, "Back");
            this.back_button.UseVisualStyleBackColor = false;
            this.back_button.Click += new System.EventHandler(this.back_button_Click);
            // 
            // head_menu
            // 
            this.head_menu.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.head_menu.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.head_menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuToolStripMenuItem,
            this.aboutToolStripMenuItem});
            this.head_menu.Location = new System.Drawing.Point(0, 0);
            this.head_menu.Name = "head_menu";
            this.head_menu.Size = new System.Drawing.Size(433, 24);
            this.head_menu.TabIndex = 101;
            this.head_menu.Text = "Menu";
            // 
            // menuToolStripMenuItem
            // 
            this.menuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.menuToolStripMenuItem.Name = "menuToolStripMenuItem";
            this.menuToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.menuToolStripMenuItem.Text = "Menu";
            this.menuToolStripMenuItem.ToolTipText = "Menu";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.ToolTipText = "Exit application";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.applicationToolStripMenuItem,
            this.developersToolStripMenuItem});
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.ToolTipText = "About";
            // 
            // applicationToolStripMenuItem
            // 
            this.applicationToolStripMenuItem.Name = "applicationToolStripMenuItem";
            this.applicationToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
            this.applicationToolStripMenuItem.Text = "Application";
            this.applicationToolStripMenuItem.ToolTipText = "About application";
            // 
            // developersToolStripMenuItem
            // 
            this.developersToolStripMenuItem.Name = "developersToolStripMenuItem";
            this.developersToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
            this.developersToolStripMenuItem.Text = "Developers";
            this.developersToolStripMenuItem.ToolTipText = "About developers";
            // 
            // toolTip
            // 
            this.toolTip.BackColor = System.Drawing.Color.LightSkyBlue;
            // 
            // bASCII
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CodeLab.Properties.Resources.begc;
            this.ClientSize = new System.Drawing.Size(433, 406);
            this.Controls.Add(this.clear_button);
            this.Controls.Add(this.output);
            this.Controls.Add(this.outputTag);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.run_button);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.viewCode_button);
            this.Controls.Add(this.home_button);
            this.Controls.Add(this.back_button);
            this.Controls.Add(this.head_menu);
            this.Name = "bASCII";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ASCII value";
            this.head_menu.ResumeLayout(false);
            this.head_menu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button clear_button;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.Label output;
        private System.Windows.Forms.Label outputTag;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button run_button;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button viewCode_button;
        private System.Windows.Forms.Button home_button;
        private System.Windows.Forms.Button back_button;
        private System.Windows.Forms.MenuStrip head_menu;
        private System.Windows.Forms.ToolStripMenuItem menuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem applicationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem developersToolStripMenuItem;
    }
}