﻿namespace CodeLab
{
    partial class bHWCSRPcode
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(bHWCSRPcode));
            this.show_code = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // show_code
            // 
            this.show_code.AllowDrop = true;
            this.show_code.BackColor = System.Drawing.Color.Black;
            this.show_code.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.show_code.Dock = System.Windows.Forms.DockStyle.Fill;
            this.show_code.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.show_code.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.show_code.Location = new System.Drawing.Point(0, 0);
            this.show_code.MaxLength = 999999999;
            this.show_code.Multiline = true;
            this.show_code.Name = "show_code";
            this.show_code.ReadOnly = true;
            this.show_code.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.show_code.Size = new System.Drawing.Size(503, 369);
            this.show_code.TabIndex = 4;
            this.show_code.Text = resources.GetString("show_code.Text");
            // 
            // bHWCSRPcode
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(503, 369);
            this.Controls.Add(this.show_code);
            this.Name = "bHWCSRPcode";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "C# code";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox show_code;
    }
}