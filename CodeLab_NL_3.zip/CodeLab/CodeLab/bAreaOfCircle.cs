﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CodeLab
{
    public partial class bAreaOfCircle : Form
    {
        public bAreaOfCircle()
        {
            InitializeComponent();
        }

        private void back_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            beginnerCodes bc = new beginnerCodes();
            bc.Show();
        }

        private void home_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home h = new Home();
            h.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.ExitThread();
        }

        private void clear_button_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            output.Text = "";
        }

        private void run_button_Click(object sender, EventArgs e)
        {
            double value1 = double.Parse(textBox1.Text);
            double area = 3.141592654 * value1 * value1;
            output.Text = "Area of the circle is " + System.Convert.ToString(area);
        }
    }
}
