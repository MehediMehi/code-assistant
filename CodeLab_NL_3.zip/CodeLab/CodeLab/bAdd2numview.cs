﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CodeLab
{
    public partial class bAdd2numview : Form
    {
        public bAdd2numview()
        {
            InitializeComponent();
        }

        private void viewCPPcode_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            bAdd2numCPPcode cp = new bAdd2numCPPcode();
            cp.ShowDialog();
        }

        private void viewCcode_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            bAdd2numCcode c = new bAdd2numCcode();
            c.ShowDialog();
        }

        private void viewCSRPcode_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            bAdd2numCSRPcode cs = new bAdd2numCSRPcode();
            cs.ShowDialog();
        }
    }
}
